﻿// vars
// Settings

"use strict";

window.s58 = window.s58 || {};

s58.vars = {
    alertOnError: false,
    autoOrient: true,
    orient: 0,
    closeTo: 0.0001,
    pageConsoleIntervalMs: 200
};
